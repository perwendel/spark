export default function () { console.log("Hello, I'm a .mjs file"); }
