console.log("Hello JavaScript");
